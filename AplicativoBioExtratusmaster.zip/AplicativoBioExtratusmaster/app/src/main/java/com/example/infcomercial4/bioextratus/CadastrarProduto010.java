package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.infcomercial4.bioextratus.BDbioextratus.ProdutosBD;
import com.example.infcomercial4.bioextratus.fragments.ProdutosCreateFragment;
import com.example.infcomercial4.bioextratus.model.ProdutoModel;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;

public class CadastrarProduto010 extends AppCompatActivity {
    private EditText editCodigo;
    private EditText editGrupo;
    private EditText editFamLin;
    private EditText editLinhaProd;
    private EditText editVolumetria;
    private EditText editTipo;
    private EditText editUnidade;
    private EditText editArmazem;
    private EditText editTEPadrao;
    private EditText editTSPadrao;
    private EditText editSegUnMed;
    private EditText editFatorConv;
    private EditText editOrdExp;
    private EditText editCodBarras1;
    private EditText editCodBarras;
    private Button btnCapture;
    private Button btnIncluir;
    private Button btnAlterar;
    private Object view;
    ListView lista;
    ProdutosBD bd;
    ArrayList<ProdutoModel> listView_Produtos;
    ProdutoModel produtos;
    ArrayAdapter adapter;
    private ProdutosCreateFragment createFragment = null;
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.cadastrar_produto_activiy);

        editCodigo =(EditText)findViewById(R.id.editCodigo);
        editGrupo =(EditText)findViewById(R.id.editGrupo);
        editFamLin =(EditText)findViewById(R.id.editFamLin);
        editLinhaProd =(EditText)findViewById(R.id.editLinhaProd);
        editVolumetria =(EditText)findViewById(R.id.editVolumetria);
        editTipo =(EditText)findViewById(R.id.editTipo);
        editUnidade =(EditText)findViewById(R.id.editUnidade);
        editArmazem =(EditText)findViewById(R.id.editArmazem);
        editTEPadrao =(EditText)findViewById(R.id.editTEPadrao);
        editTSPadrao =(EditText)findViewById(R.id.editTSPadrao);
        editSegUnMed =(EditText)findViewById(R.id.editSegUnMed);
        editFatorConv =(EditText)findViewById(R.id.editFatorCon);
        editOrdExp =(EditText)findViewById(R.id.editOrdExp);
        editCodBarras1 =(EditText)findViewById(R.id.editCodBarras1);
        editCodBarras =(EditText)findViewById(R.id.editCodBarras);
        btnCapture= (Button)findViewById(R.id.btnCapture);
        btnIncluir =(Button) findViewById(R.id.btnIncluir);
        btnAlterar =(Button)findViewById(R.id.btnAlterar);
        btnIncluir.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(CadastrarProduto010.this, FormularioProdutos.class);
                startActivity(intent);
            }

        });
        btnCapture= (Button)findViewById(R.id.btnCapture);
        btnCapture.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                IntentIntegrator intent = new IntentIntegrator(CadastrarProduto010.this);
                intent.initiateScan();

            }

        });



            registerForContextMenu(lista);








    }
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        MenuItem menuDelete = menu.add("Deletar este produto");
        menuDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
            public boolean onMenuItemClick(MenuItem item){
                bd= new ProdutosBD((CadastrarProduto010.this));
                bd.deletarProduto(produtos);
                bd.close();
                carregarProduto();
                return true;
            }

        });
    }




    @Override
    protected void onResume(){
        super.onResume();
        carregarProduto();

    }


    public void carregarProduto(){
        bd= new ProdutosBD(CadastrarProduto010.this);
        listView_Produtos= bd.getLista();
        bd.close();

        if(listView_Produtos != null){
            adapter = new ArrayAdapter<ProdutoModel>(CadastrarProduto010.this,android.R.layout.simple_list_item_1,listView_Produtos);
            lista.setAdapter(adapter);
        }
        finish();

    }

    public void barcodeCapture(View view) {
        IntentIntegrator intent = new IntentIntegrator(CadastrarProduto010.this);
        intent.initiateScan();
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null){
            String barcode = result.getContents();
            if (barcode != null && !"".equals(barcode)){
                createFragment.setBarCode(barcode);
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }





}

