package com.example.infcomercial4.bioextratus;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.infcomercial4.bioextratus.adapters.InventarioAdapter;
import com.example.infcomercial4.bioextratus.model.InventarioModel;
import com.example.infcomercial4.bioextratus.model.ProdutoModel;

import java.util.List;

public class ListarInventario extends AppCompatActivity {

    private ListView lsvInventario;
    private List<InventarioModel>inventarioList;
    private ArrayAdapter<InventarioAdapter>adapterInventario;

    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);

    }
}
