package com.example.infcomercial4.bioextratus;

class SQLiteOpenHolder {
}
