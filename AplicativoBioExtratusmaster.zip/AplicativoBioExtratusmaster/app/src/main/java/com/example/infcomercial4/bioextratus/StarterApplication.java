package com.example.infcomercial4.bioextratus;

import android.app.Application;
import  com.parse.Parse;
import com.parse.ParseACL;
import com.parse.ParseObject;


public class StarterApplication  extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

        // Habilite armazenamento local.
        Parse.enableLocalDatastore(this);

        // Codigo de configuração do App
        Parse.initialize(new Parse.Configuration.   Builder(getApplicationContext())
                .applicationId("wfNldRi8HU6kPqfu8KEJVn0BaXwSme32oEJ5R27Y")
                .clientKey("DNO0P6dOz8D3UbrU4cBq3XdrEENUNwD4xzwoLjpE")
                .server("https://parseapi.back4app.com/")
                .build()
        );
        //Teste de configuração do app
        //ParseUser.enableAutomaticUser();
        ParseACL defaultACL = new ParseACL();
        // Optionally enable public read access.
        defaultACL.setPublicReadAccess(true);
        //ParseACL.setDefaultACL(defaultACL, true);
    }
}