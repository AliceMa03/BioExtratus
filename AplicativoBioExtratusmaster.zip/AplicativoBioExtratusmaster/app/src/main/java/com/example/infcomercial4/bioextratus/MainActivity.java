package com.example.infcomercial4.bioextratus;




public abstract class MainActivity {



}