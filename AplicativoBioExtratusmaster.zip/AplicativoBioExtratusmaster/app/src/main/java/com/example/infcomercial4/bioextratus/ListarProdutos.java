package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.example.infcomercial4.bioextratus.adapters.InventarioAdapter;
import com.example.infcomercial4.bioextratus.model.InventarioModel;
import com.example.infcomercial4.bioextratus.model.ProdutoModel;
import com.example.infcomercial4.bioextratus.adapters.ProductAdapter;

import java.util.ArrayList;
import java.util.List;

public class ListarProdutos extends AppCompatActivity {

    private ListView lsvProdutos;
    private List<ProdutoModel> produtoList;
    private ProductAdapter adapterProduto;
    private EditText textoId;
    private Button btnAdicionar;
    private ArrayAdapter<String> itensAdapter;
    private SQLiteDatabase bancoDados;
    private ArrayList<String> itens;
    private ArrayList<Integer> ids;

    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_produtos);
        try {

            //Recuperar componentes

            textoId = (EditText) findViewById(R.id.textoId);
            btnAdicionar = (Button) findViewById(R.id.btnAdicionar);

            //Banco de Dados
            bancoDados = openOrCreateDatabase("produtos", MODE_PRIVATE, null);
            //tabela de produtos
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS produtos(id INTEGER PRIMARY KEY AUTOINCREMENT, produto VARCHAR)");
            btnAdicionar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String textoDigitado = textoId.getText().toString();
                    salvarProduto(textoDigitado);
                    bancoDados.execSQL("INSERT INTO produtos (produto) VALUES('" + textoDigitado + "')");

                }
            });
            lsvProdutos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int position, long id) {
                    Log.i("ITEM:", position + "/ " + ids.get( position));
                    //removerProdutos(ids.get(position));
                }
            });
            //Listar tarefas
            recuperarProdutos();
            //Recupera os produtos
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM  produtos",null);

            int indiceColunaId = cursor.getColumnIndex("id");
            int indiceColunaProduto = cursor.getColumnIndex("produto");

            //listar os produtos
            cursor.moveToFirst();
            while(cursor != null){
                Log.i("Resultado - ","Codigo Produto:" + cursor.getString(indiceColunaProduto) + "Produtos:" + cursor.getString(indiceColunaProduto));

                cursor.moveToNext();
            }
        }  catch(Exception e){
                e.printStackTrace();
            }

    }
    private void salvarProduto(String texto){

        try{
            if(texto.equals("")){
                Toast.makeText(ListarProdutos.this,"Digite um produto",Toast.LENGTH_SHORT).show();
            }else {
                bancoDados.execSQL("INSERT INTO produtos(produto) VALUES('" + texto + "')");
                Toast.makeText(ListarProdutos.this, "Produto salvo com sucesso", Toast.LENGTH_SHORT).show();
                recuperarProdutos();
                textoId.setText("");
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
    private void recuperarProdutos(){
        try{
            Cursor cursor = bancoDados.rawQuery("SELECT * FROM  produtos ORDER BY id DESC",null);

            int indiceColunaId = cursor.getColumnIndex("id");
            int indiceColunaProduto = cursor.getColumnIndex("produto");

            //Criar adaptador
            lsvProdutos = (ListView) findViewById(R.id.lsvProdutos);
            itens = new ArrayList<String>();
            ids = new ArrayList<Integer>();
            itensAdapter = new ArrayAdapter<String>(getApplicationContext(),android.R.layout.simple_list_item_1,android.R.id.text2,itens);
           lsvProdutos.setAdapter(itensAdapter);

            //listar os produtos
            cursor.moveToFirst();
            while(cursor != null){
                Log.i("Resultado - ","Produto:" + cursor.getString(indiceColunaProduto));
                itens.add(cursor.getString(indiceColunaProduto));
                ids.add(Integer.parseInt(cursor.getString(indiceColunaId)));
                cursor.moveToNext();
            }
        }  catch(Exception e){
            e.printStackTrace();
        }
        }
        private void removerProdutos(Integer id){

        try{
            bancoDados.execSQL("DELETE FROM produtos WHERE id=" +id);
            recuperarProdutos();
            Toast.makeText(ListarProdutos.this, "Produto removido com sucesso", Toast.LENGTH_SHORT).show();

        }catch (Exception e){
                e.printStackTrace();
        }
        }
    }


