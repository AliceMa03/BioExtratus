package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.example.infcomercial4.bioextratus.adapters.InventarioAdapter;
import com.example.infcomercial4.bioextratus.model.InventarioModel;
import com.example.infcomercial4.bioextratus.model.ProdutoModel;
import com.example.infcomercial4.bioextratus.adapters.ProductAdapter;

import java.util.List;

public class ListarProdutos extends AppCompatActivity {

    private ListView lsvProdutos;
    private List<ProdutoModel> produtoList;
    private ProductAdapter adapterProduto;

    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listar_produtos);

        //Buscar todos os produtos no Banco

        this.lsvProdutos = (ListView)findViewById(R.id.lsvProdutos);
        this.adapterProduto = new ProductAdapter(ListarProdutos.this,this.produtoList);
        this.lsvProdutos.setAdapter(this.adapterProduto);

    }

}
