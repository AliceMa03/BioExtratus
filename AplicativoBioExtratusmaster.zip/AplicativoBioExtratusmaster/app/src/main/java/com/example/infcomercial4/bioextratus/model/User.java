package com.example.infcomercial4.bioextratus.model;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;

import com.example.infcomercial4.bioextratus.bd.DataBase;

import java.util.ArrayList;

public class User {
    private int id;
    private String email;
    private String name;
    private String password;
    private Context context;

    public User(Context context) {

    }

    public User() {

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean excluir(){

        DataBase dataBase= null;
        SQLiteDatabase sqLiteDatabase= null;

        try {
            dataBase = new DataBase(context);
            sqLiteDatabase = dataBase.getReadableDatabase();

            sqLiteDatabase.beginTransaction();
            sqLiteDatabase.delete("usuario","id=?", new String[]{String.valueOf(id)});

           excluir() = true;
            sqLiteDatabase.setTransactionSuccessful();
            sqLiteDatabase.endTransaction();
            return true;


        }catch(Exception e){
            e.printStackTrace();
            sqLiteDatabase.endTransaction();
            return false;
        }finally{

            if (sqLiteDatabase != null)
                sqLiteDatabase.close();
            if (dataBase != null)
                dataBase.close();
        }

    }




    public boolean salvar(){

        DataBase dataBase= null;
        SQLiteDatabase sqLiteDatabase= null;

        try {
            dataBase = new DataBase(context);
            sqLiteDatabase = dataBase.getReadableDatabase();
            String sql = "";
            if (id == -1) {
                sql = "INSERT INTO usuarios (name,email,password) VALUES (?,?,?)";
            } else {
                sql = "UPDATE usuario SER name=?,email=?,senha=? WHERE codigo=?";
            }
            sqLiteDatabase.beginTransaction();
            SQLiteStatement sqLiteStatement = sqLiteDatabase.compileStatement(sql);
            sqLiteStatement.clearBindings();
            sqLiteStatement.bindString(1, name);
            sqLiteStatement.bindString(2, email);
            sqLiteStatement.bindString(3, password);

            if (id == -1)
                sqLiteStatement.bindString(4, String.valueOf(id));
                sqLiteStatement.executeInsert();
                sqLiteDatabase.setTransactionSuccessful();
                sqLiteDatabase.endTransaction();
                return true;


            }catch(Exception e){
                e.printStackTrace();
                sqLiteDatabase.endTransaction();
                return false;
            }finally{

                if (sqLiteDatabase != null)
                    sqLiteDatabase.close();
                if (dataBase != null)
                    dataBase.close();
            }


    }


    public ArrayList<User> getUsuarios(){
        DataBase dataBase= null;
        SQLiteDatabase sqLiteDatabase= null;
        Cursor cursor=null;
        ArrayList<User> usuarios = new ArrayList<>();
        try {
            dataBase = new DataBase(context);
            sqLiteDatabase = dataBase.getReadableDatabase();
            cursor= sqLiteDatabase.query("usuario",null,null,null,null,null,null);
            while(cursor.moveToNext()){
                User usuario = new User(context);
                usuario.id= cursor.getInt(cursor.getColumnIndex("Codigo"));
                usuario.name=cursor.getString(cursor.getColumnIndex("Nome"));
                usuario.email=cursor.getString(cursor.getColumnIndex("Email"));
                usuario.password=cursor.getString(cursor.getColumnIndex("Senha"));
                usuarios.add(usuario);


            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if ((cursor!=null)&&(!cursor.isClosed()))
                    cursor.close();
            if (sqLiteDatabase!=null)
                sqLiteDatabase.close();
            if(dataBase != null)
                dataBase.close();
        }
        return  usuarios;
    }

    public void carregaUsuarioPeloCodigo(int id){
        DataBase dataBase= null;
        SQLiteDatabase sqLiteDatabase= null;
        Cursor cursor=null;

        try {
            dataBase = new DataBase(context);
            sqLiteDatabase = dataBase.getReadableDatabase();
            cursor= sqLiteDatabase.query("usuario",null, "codigo = ?",new String[]{String.valueOf(id)},null,null,null);
            while(cursor.moveToNext()){

                this.id= cursor.getInt(cursor.getColumnIndex("Codigo"));
                name=cursor.getString(cursor.getColumnIndex("Nome"));
                email=cursor.getString(cursor.getColumnIndex("Email"));
                password=cursor.getString(cursor.getColumnIndex("Senha"));



            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if ((cursor!=null)&&(!cursor.isClosed()))
                cursor.close();
            if (sqLiteDatabase!=null)
                sqLiteDatabase.close();
            if(dataBase != null)
                dataBase.close();
        }
        return  usuarios;

    }
}
