package com.example.infcomercial4.bioextratus.interfaces;

public interface OnItemSelectedListener<T extends Object> {
    void select(T item);
}
