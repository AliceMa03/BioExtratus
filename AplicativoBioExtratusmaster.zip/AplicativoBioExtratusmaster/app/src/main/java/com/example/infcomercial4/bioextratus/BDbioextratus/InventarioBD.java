package com.example.infcomercial4.bioextratus.BDbioextratus;

import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.lang.String;

import com.example.infcomercial4.bioextratus.model.InventarioModel;
import com.example.infcomercial4.bioextratus.model.ProdutoModel;

import java.util.ArrayList;
import java.util.List;

public class InventarioBD extends SQLiteOpenHelper {

    private static final String DATABASE = "bdinventario";
    private static final int VERSION = 1;


    public InventarioBD(Context context) {
        super(context, DATABASE, null, VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String inventario = "CREATE TABLE produtos(codigo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, descricao TEXT NOT NULL, lote INTEGER, armazem INTEGER, quantidade INTEGER);";
        db.execSQL(inventario);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versaoVelha, int versaoNova) {
        String inventario = "DROP TABLE IF EXISTS inventario";

        db.execSQL(inventario);
    }



    public void salvarInventario(InventarioModel inventario) {
        ContentValues values = new ContentValues();

        values.put("descricao", inventario.getDescricao());
        values.put("lote", inventario.getLote());
        values.put("quantidade", inventario.getQuantidade());
        values.put("armazem", inventario.getArmazem());


        getWritableDatabase().insert("inventario", null, values);

        String[] args = {DATABASE.toString()};
        getWritableDatabase().update("inventario", values, "codigo=?", args);


    }
    public List<InventarioModel>getListaProdutos(){
        List<InventarioModel>listaInventario = new ArrayList<>();
        SQLiteDatabase db= null;
        Cursor cursor;

        String query = "SELECT * FROM  inventario;";
        try {

                    cursor= db.rawQuery(query,null);
                    if(cursor.moveToFirst()){
                        InventarioModel inventario = null;
                        do{
                            inventario = new InventarioModel();
                            inventario.setCodigo(cursor.getInt(0));
                            inventario.setDescricao(cursor.getString(1));
                            inventario.setLote(cursor.getString(2));
                            inventario.setArmazem(cursor.getInt(3));
                            inventario.setQuantidade(cursor.getInt(4));

                            listaInventario.add(inventario);
                        }while(cursor.moveToNext());
                    }
        }catch (Exception e){
            Log.d("ERRO LISTA INVENTARIO","Erro ao retornar inventario");
                    return null;
        }finally{
            if(db!=null){
                db.close();
            }
        }
        return  listaInventario;
    }
    public void alterarInventario(InventarioModel inventario) {
        ContentValues values = new ContentValues();
        values.put("codigo",inventario.getCodigo());
        values.put("quantidade",inventario.getQuantidade());
        values.put("armazem",inventario.getArmazem());
        values.put("lote",inventario.getLote());
        getWritableDatabase().insert("inventario", null, values);
        String[] args = {DATABASE.toString()};
        getWritableDatabase().update("inventario", values, "codigo=?", args);
    }


    public void deletarProduto(InventarioModel inventario) {
        String[] args = {DATABASE.toString()};
        getWritableDatabase().delete("inventario", "codigo=?", args);


    }


}

