package com.example.infcomercial4.bioextratus.fragments;

class R {
    public static Object layout;
}
