package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.infcomercial4.bioextratus.BDbioextratus.InventarioBD;
import com.example.infcomercial4.bioextratus.model.InventarioModel;

public class FormularioInventario070 extends AppCompatActivity {
    private EditText txtCodigo;
    private EditText txtArmazem;
    private EditText txtLote;
    private EditText txtQuantidade;

    private Button btnAlterar;
    InventarioBD inventarioBD;

    InventarioModel editarInventario,inventario;

    protected void onCreate(Bundle savedInstanceState){

        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventario_activity);

        inventarioBD= new InventarioBD(FormularioInventario070.this);
        Intent intent = getIntent();
        editarInventario = (InventarioModel) intent.getSerializableExtra("produto-escolhido");

        txtCodigo =(EditText)findViewById(R.id.txtCodigo);
        txtLote = (EditText)findViewById(R.id.txtLote);
        txtQuantidade= (EditText)findViewById(R.id.txtQuantidade);
        txtArmazem =(EditText)findViewById(R.id.txtArmazem);

        btnAlterar =(Button)findViewById(R.id.btnAlterar);

        if (editarInventario!=null){
            btnAlterar.setText("Alterar");
        }else{
            btnAlterar.setText("Cadastrar");
        }
        btnAlterar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                inventario.setQuantidade(Integer.parseInt(txtQuantidade.getText().toString()));
                inventario.setArmazem(Integer.parseInt(txtArmazem.getText().toString()));
                inventario.setLote(txtLote.getText().toString());
                inventario.setCodigo(Integer.parseInt(txtCodigo.getText().toString()));

                if(btnAlterar.getText().toString().equals("Cadastrar")){
                    inventarioBD.salvarInventario(inventario);
                    inventarioBD.close();
                }else{
                    inventarioBD.alterarInventario(inventario);
                    inventarioBD.close();
                }

            }


        });
    }
}



