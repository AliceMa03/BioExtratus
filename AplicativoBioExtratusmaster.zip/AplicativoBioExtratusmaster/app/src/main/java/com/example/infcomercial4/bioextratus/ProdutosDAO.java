package com.example.infcomercial4.bioextratus;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.infcomercial4.bioextratus.model.ProdutoModel;

import java.util.List;

public class ProdutosDAO extends SQLiteOpenHolder {
private static final int VERSAO = 1;
private static final String TABELA = "produto";
private static final String DATABASE = "Banco";

public ProdutosDAO (Context context){
    super(context,DATABASE,null,VERSAO);
}

public void onCreate(SQLiteDatabase db){
    String ddl = "CREATE TABLE IF NOT EXISTS" + TABELA +
            "(id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL," +
            "descricao TEXT," +
            "quantidade INTEGER);";
    db.execSQL(ddl);
}
/*public  void inserirProduto(Produto produto){
    ContentValues values = new ContentValues();
    values.put("descricao",produto.getDescricao());
    String args[]= {Integer.toString(produto.getId())};
    getWritableDatabase().update(TABELA, values, "id=?", args);
}
    public Cursor getCursorListaProduto(){
        List<ProdutoModel> lista = new ArrayList<Produto>();
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM " + TABELA + ";", null);
        return cursor;
    }

    public List<ProdutoModel> getListaProduto(){
        List<ProdutoModel> lista = new ArrayList<Produto>();
        Cursor cursor = getReadableDatabase().rawQuery("SELECT * FROM " + TABELA + ";", null);
        cursor.moveToFirst();
        while (cursor.moveToNext()){
            ProdutoModel produto = new Produto();
            produto.setId(cursor.getInt(cursor.getColumnIndex("id")));
            produto.setNome(cursor.getString(cursor.getColumnIndex("nome")));
            produto.setPreco(cursor.getFloat(cursor.getColumnIndex("preco")));
            produto.setQuantidade(cursor.getInt(cursor.getColumnIndex("quantidade")));
            lista.add(produto);
        }
        cursor.close();
        return lista;
    }

    public Produto getProdutoByID(int id){
        Cursor cursor = getReadableDatabase().query(TABELA, new String[]{"id","nome","preco","quantidade"}, "id=" + id, null,null, null, null);
        cursor.moveToFirst();
        ProdutoModel produto = new Produto();
        produto.setId(cursor.getInt(cursor.getColumnIndex("id")));
        produto.setNome(cursor.getString(cursor.getColumnIndex("nome")));
        produto.setPreco(cursor.getFloat(cursor.getColumnIndex("preco")));
        produto.setQuantidade(cursor.getInt(cursor.getColumnIndex("quantidade")));
        cursor.close();
        return produto;
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }*/

}

//Outro exemplo para testar com cadastro de produto
/*
public class ActivityProduto extends AppCompatActivity {

    private ProdutoDAO produtoHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_produto);
        produtoHelper = new ProdutoDAO(this);
    }

    public void onClick(View view){
        try{
            EditText edtNome = (EditText) findViewById(R.id.edtNome);
            EditText edtPreco = (EditText ) findViewById(R.id.edtPreco);
            EditText edtQuantidade = (EditText) findViewById(R.id.edtQuantidade);
            Produto produto = new Produto();
            produto.setNome(edtNome.getText().toString());
            produto.setPreco(Float.parseFloat(edtPreco.getText().toString()));
            produto.setQuantidade(Integer.parseInt(edtQuantidade.getText().toString()));
            produtoHelper.inserirProduto(produto);

            Toast.makeText(this, "Cadastrado com sucesso!", Toast.LENGTH_SHORT).show();
            this.finish();
        }catch (Exception e){
            e.getStackTrace();
        }


    }
}
*/
