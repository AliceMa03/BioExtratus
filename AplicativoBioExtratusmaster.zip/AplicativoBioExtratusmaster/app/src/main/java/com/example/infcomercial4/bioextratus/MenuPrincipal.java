package com.example.infcomercial4.bioextratus;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toolbar;

public class MenuPrincipal extends AppCompatActivity {
    private Button buttonProduto;
    private Button buttonInventario;
    private Button btnLista;
    private Toolbar toolbar;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_principal);

        buttonProduto= (Button)findViewById(R.id.buttonProduto);
        buttonProduto.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                Intent intent = new Intent(MenuPrincipal.this, CadastrarProdutoActivity.class);
                startActivity(intent);

            }

        });
        buttonInventario= (Button)findViewById(R.id.buttonInventario);
        buttonInventario.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                Intent intent = new Intent(MenuPrincipal.this, CadastrarInventario.class);
                startActivity(intent);

            }

        });
        btnLista = (Button)findViewById(R.id.btnLista);
        btnLista.setOnClickListener(new android.view.View.OnClickListener(){
            public  void onClick(View view){
                Intent intent = new Intent(MenuPrincipal.this, ListarProdutos.class);
                startActivity(intent);
            }

        });

    }




    public void abrirCadastroProduto(View view) {
        Intent it = new Intent(MenuPrincipal.this, CadastrarProdutoActivity.class);
        startActivity(it);

    }

    public void abrirCadastrarInventario(View view) {
        Intent it = new Intent(MenuPrincipal.this, CadastrarInventario.class);
        startActivity(it);


    }
    public void abrirListaProdutos(View view) {
        Intent it = new Intent(MenuPrincipal.this, ListarProdutos.class);
        startActivity(it);

    }
}