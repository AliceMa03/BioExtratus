package com.example.infcomercial4.bioextratus;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.Toolbar;

public class MenuPrincipal extends AppCompatActivity {
    private Button buttonProduto;
    private Button buttonInventario;
    private Button btnLista;
    private Button btnSair;
    private Toolbar toolbar;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_principal);

        buttonProduto= (Button)findViewById(R.id.buttonProduto);
        buttonProduto.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                Intent intent = new Intent(MenuPrincipal.this, CadastrarProduto010.class);
                startActivity(intent);

            }

        });
        buttonInventario= (Button)findViewById(R.id.buttonInventario);
        buttonInventario.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                Intent intent = new Intent(MenuPrincipal.this, CadastrarInventario010.class);
                startActivity(intent);

            }

        });
        btnLista = (Button)findViewById(R.id.btnLista);
        btnLista.setOnClickListener(new android.view.View.OnClickListener(){
            public  void onClick(View view){
                Intent intent = new Intent(MenuPrincipal.this, ListarProdutos.class);
                startActivity(intent);
            }

        });
        btnSair = (Button)findViewById(R.id.btnSair);
        btnSair.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View view){
                finish();
            }
        });

    }




    public void abrirCadastroProduto(View view) {
        Intent it = new Intent(MenuPrincipal.this, CadastrarProduto010.class);
        startActivity(it);

    }

    public void abrirCadastrarInventario(View view) {
        Intent it = new Intent(MenuPrincipal.this, CadastrarInventario010.class);
        startActivity(it);


    }
    public void abrirListaProdutos(View view) {
        Intent it = new Intent(MenuPrincipal.this, ListarProdutos.class);
        startActivity(it);

    }
    public void verificarEmpresa(){
        Integer empresa = null;
        switch (empresa){
            case 1:
                Intent intent = new Intent(MenuPrincipal.this, CadastrarInventario010.class);
                startActivity(intent);
                break;
            case 2:
                Intent intent2 = new Intent(MenuPrincipal.this, CadastrarInventario020.class);
                startActivity(intent2);
                break;
            case 3:
                Intent intent3 = new Intent(MenuPrincipal.this, CadastrarInventario030.class);
                startActivity(intent3);
                break;
            case 4:
                Intent intent4 = new Intent(MenuPrincipal.this, CadastrarInventario040.class);
                startActivity(intent4);
                break;
            case 5:
                Intent intent5 = new Intent(MenuPrincipal.this, CadastrarInventario050.class);
                startActivity(intent5);
                break;
            case 6:
                Intent intent6 = new Intent(MenuPrincipal.this, CadastrarInventario060.class);
                startActivity(intent6);
                break;
            case 7:
                Intent intent7 = new Intent(MenuPrincipal.this, CadastrarInventario080.class);
                startActivity(intent7);
                break;
            case 8:
                Intent intent8 = new Intent(MenuPrincipal.this, CadastrarInventario090.class);
                startActivity(intent8);
                break;
            case 9:
                Intent intent9 = new Intent(MenuPrincipal.this, CadastrarInventario100.class);
                startActivity(intent9);
                break;
            case 10:
                Intent intent10 = new Intent(MenuPrincipal.this, CadastrarInventario110.class);
                startActivity(intent10);
                break;
            case 11:
                Intent intent11 = new Intent(MenuPrincipal.this, CadastrarInventario120.class);
                startActivity(intent11);
                break;
            case 12:
                Intent intent12 = new Intent(MenuPrincipal.this, CadastrarInventario130.class);
                startActivity(intent12);
                break;
            case 13:
                Intent intent13 = new Intent(MenuPrincipal.this, CadastrarInventario140.class);
                startActivity(intent13);
                break;
            case 14:
                Intent intent14 = new Intent(MenuPrincipal.this, CadastrarInventario150.class);
                startActivity(intent14);
                break;
            case 15:
                Intent intent15 = new Intent(MenuPrincipal.this, CadastrarInventario160.class);
                startActivity(intent15);
                break;
            case 16:
                Intent intent16 = new Intent(MenuPrincipal.this, CadastrarInventario170.class);
                startActivity(intent16);
                break;
            case 17:
                Intent intent17 = new Intent(MenuPrincipal.this, CadastrarInventario180.class);
                startActivity(intent17);
                break;


        }
    }


}