package com.example.infcomercial4.bioextratus.BDbioextratus;

import android.app.Fragment;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.lang.String;

import java.util.ArrayList;

import com.example.infcomercial4.bioextratus.model.ProdutoModel;
public class ProdutosBD extends SQLiteOpenHelper {

    private static final String DATABASE = "bdprodutos";
    private static final int VERSION = 1;
    private Fragment cursor;
    public ProdutoModel produtos;

    public ProdutosBD(Context context) {
        super(context, DATABASE, null, VERSION);

    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        String produto = "CREATE TABLE produtos(codigo INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, descricao TEXT NOL NULL, grupo INTEGER, famLin INTEGER, linhaProd INTEGER, volumetria" +
                "INTEGER, tipo INTEGER, armazem INTEGER, tepadrao INETEGER, tspadrao INTEGER, segUnMed INTEGER, fatorConv INTEGER, ordExp INTEGER, codBarras1 INTEGER, codBarras INTEGER);";
        db.execSQL(produto);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int versaoVelha, int versaoNova) {
        String produto = "DROP TABLE IF EXISTS produtos";

        db.execSQL(produto);
    }

    public void salvarProduto(ProdutoModel produtos) {
        ContentValues values = new ContentValues();

        values.put("descricao", produtos.getDescricao());
        values.put("grupo", produtos.getGrupo());
        values.put("famLin", produtos.getFamLin());
        values.put("linhaProd", produtos.getLinhaProd());
        values.put("volumetria", produtos.getVolumetria());
        values.put("tipo", produtos.getTipo());
        values.put("armazem", produtos.getArmazem());
        values.put("tepadrao", produtos.getTePadrao());
        values.put("tspadrao", produtos.getTsPadrao());
        values.put("segUnMed", produtos.getSegUnMed());
        values.put("fatorConv", produtos.getFatorConv());
        values.put("ordExp", produtos.getOrdExp());
        values.put("codBarras", produtos.getCodBarras());
        values.put("codBarras1", produtos.getCodBarras1());
        values.put("tipoConv", produtos.getTipoConv());

        getWritableDatabase().insert("produtos", null, values);
    }

    public void alterarProduto(ProdutoModel produtos) {
        ContentValues values = new ContentValues();

        values.put("descricao", produtos.getDescricao());
        values.put("grupo", produtos.getGrupo());
        values.put("famLin", produtos.getFamLin());
        values.put("linhaProd", produtos.getLinhaProd());
        values.put("volumetria", produtos.getVolumetria());
        values.put("tipo", produtos.getTipo());
        values.put("armazem", produtos.getArmazem());
        values.put("tepadrao", produtos.getTePadrao());
        values.put("tspadrao", produtos.getTsPadrao());
        values.put("segUnMed", produtos.getSegUnMed());
        values.put("fatorConv", produtos.getFatorConv());
        values.put("ordExp", produtos.getOrdExp());
        values.put("codBarras", produtos.getCodBarras());
        values.put("codBarras1", produtos.getCodBarras1());
        values.put("tipoConv", produtos.getTipoConv());

        getWritableDatabase().insert("produtos", null, values);
        String[] args = {DATABASE.toString()};
        getWritableDatabase().update("produtos", values, "codigo=?", args);
    }

    public ArrayList<ProdutoModel>getLista() {
        String[] columns = {"codigo", "descricao", "grupo", "famLin", "linhaProd", "volumetria", "tipo", "armazem", "tepadrao", "tspadrao", "segUnMed", "fatorConv", "ordExp", "codBarras", "codBarras1", "tipoConv"};
        Cursor cursor = (Cursor) getWritableDatabase().query("produtos", null, null, null, null, null, null);
        ArrayList<ProdutoModel> produtos = new ArrayList<ProdutoModel>();

        while (cursor.moveToNext()) {
            ProdutoModel produto = new ProdutoModel();
            produto.setCodigo(cursor.getInt(0));
            produto.setDescricao(cursor.getString(1));
            produto.setGrupo(cursor.getInt(2));
            produto.setTePadrao(cursor.getInt(3));
            produto.setTsPadrao(cursor.getInt(4));
            produto.setTipo(cursor.getInt(5));
            produto.setLinhaProd(cursor.getInt(6));
            produto.setFamLin(cursor.getInt(7));
            produto.setLinhaProd(cursor.getInt(8));
            produto.setFatorConv(cursor.getInt(9));
            produto.setOrdExp(cursor.getInt(10));
            produto.setCodBarras1(cursor.getInt(11));
            produto.setCodBarras(cursor.getInt(12));

            produtos.add(produto);
        }
        return produtos;
    }



        public void deletarProduto(ProdutoModel produtos) {
            String[] args = {DATABASE.toString()};
            getWritableDatabase().delete("produtos", "codigo=?", args);


        }


    }




