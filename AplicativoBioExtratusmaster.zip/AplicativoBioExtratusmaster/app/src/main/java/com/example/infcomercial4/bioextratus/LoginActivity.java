package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import android.widget.Toast;

import com.example.infcomercial4.bioextratus.bd.DataBase;
import com.example.infcomercial4.bioextratus.helpers.InputValidation;
import com.example.infcomercial4.bioextratus.model.User;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;


import com.google.firebase.analytics.FirebaseAnalytics;
import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class LoginActivity<dataAdapter> extends AppCompatActivity {
    private final AppCompatActivity activity = LoginActivity.this;

    private NestedScrollView nestedScrollView;
    private Spinner spnGrupo;
    private String distribuidora;
    private List<String> distribuidoras = new ArrayList<String>();
    private DatabaseReference dataBaseReferencia = FirebaseDatabase.getInstance().getReference();
    private DatabaseReference usuarioReferencia = dataBaseReferencia.child("usuario");
    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPassword;
    private FirebaseAuth auth;
    private FirebaseUser user;


    private TextInputEditText textInputEditTextEmail;
    private TextInputEditText textInputEditTextPassword;

    private AppCompatButton appCompatButtonLogin;
    private AppCompatActivity appCompatButtonRegister;
    private AppCompatTextView textViewLinkRegister;

    private InputValidation inputValidation;
    private DataBase dataBase;
    private Object AdapterView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);



        distribuidoras.add("BioTerra");
        distribuidoras.add("LAmanda");
        distribuidoras.add("3M");
        distribuidoras.add("Rhunill");
        distribuidoras.add("Campidelles");
        distribuidoras.add("Semear");
        distribuidoras.add("MA");
        distribuidoras.add("BioGreen");
        distribuidoras.add("Extratus Carioca");
        distribuidoras.add("ADR");
        distribuidoras.add("BioBrazilis");
        distribuidoras.add("BioDreams");
        distribuidoras.add("RM");
        distribuidoras.add("BioDuque");
        distribuidoras.add("BioTop");
        distribuidoras.add("BioStar");
        distribuidoras.add("DBeleza");
        distribuidoras.add("Baoba");
        distribuidoras.add("JPC");

        Spinner spinner = (Spinner) findViewById(R.id.spnGrupo);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, distribuidoras);
        ArrayAdapter<String> spinnerArrayAdapter = arrayAdapter;
        spinnerArrayAdapter.setDropDownViewResource(R.layout.support_simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerArrayAdapter);
        spinner.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(android.widget.AdapterView<?> adapterView, View view, int i, long l) {

            }

            public void onItemSelected(AdapterView<?> parent, View view, int posicao, long id) {


                distribuidora = parent.getItemAtPosition(posicao).toString();

                Toast.makeText(LoginActivity.this, "Distribuidora selecionada: " + distribuidora, Toast.LENGTH_LONG).show();
            }

            public void onNothingSelected(AdapterView<?> parent) {

            }

        });

        buttonEntrar = (Button) findViewById(R.id.appCompatButtonRegister);
        buttonEntrar.setOnClickListener(new android.view.View.OnClickListener() {
            public void onClick(View v) {

                Intent intent = new Intent(LoginActivity.this, MenuPrincipal.class);
                startActivity(intent);

            }

        });
        buttonEntrar.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                String email = textInputEditTextEmail.getText().toString().trim();
                String senha = textInputEditTextPassword.getText().toString().trim();

                verificarLogin(email,senha);

            }
        });
        initViews();
        initListeners();
        initObjects();
    }

    private void login(String email, String senha) {
        auth.signInWithEmailAndPassword(email, senha).addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Intent i = new Intent(LoginActivity.this,MenuPrincipal.class);
                    startActivity(i);
                }else{
                    alerta("Email ou senha incorretos");
                }
            }
        });
    }

    /**
     * This method is to initialize views
     */
    private void initViews() {


        textInputLayoutEmail = (TextInputLayout) findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPassword = (TextInputLayout) findViewById(R.id.textInputLayoutPassword);

        textInputEditTextEmail = (TextInputEditText) findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPassword = (TextInputEditText) findViewById(R.id.textInputEditTextPassword);

        appCompatButtonLogin = (AppCompatButton) findViewById(R.id.appCompatButtonRegister);
        verificarUsuarioLogado();

    }

    /**
     * This method is to initialize listeners
     */
    private void initListeners() {
        appCompatButtonLogin.setOnClickListener((View.OnClickListener) this);

    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        dataBase = new DataBase(activity);
        inputValidation = new InputValidation(activity);

    }

    /**
     * This implemented method is to listen the click on view
     *
     * @param v
     */

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.appCompatButtonRegister:
                verifyFromSQLite();
                break;


        }
    }

    /**
     * This method is to validate the input text fields and verify login credentials from SQLite
     */
    private void verifyFromSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPassword, textInputLayoutPassword, getString(R.string.error_message_email))) {
            return;
        }


    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        textInputEditTextEmail.setText(null);
        textInputEditTextPassword.setText(null);
    }

    public Button buttonEntrar;


    public void abrirAreaPrincipal(View view) {
        Intent intent = new Intent(LoginActivity.this, MenuPrincipal.class);
        startActivity(intent);

    }


    public void abrirCadastroUsuario(View view) {
        Intent intent = new Intent(LoginActivity.this, CadastrarUsuarioActivity.class);
        startActivity(intent);


    }
    protected void onStart(){
        super.onStart();
        auth = DataBase.getFirebaseAuth();
        user = DataBase.getFirebaseUser();

        verificaUser();

    }
    private void verificaUser(){
        if(user==null){
            finish();
        }else{
            textInputEditTextEmail.setText("Email: " + user.getEmail());

        }
    }
    private  void verificarLogin(String usuario, String senha){
        ParseUser.logInInBackground(usuario, senha, new LogInCallback() {
            @Override
            public void done(ParseUser user, ParseException e) {
                if(e==null){ //sucesso no login
                    Toast.makeText(LoginActivity.this,"Login realizado com sucesso!", Toast.LENGTH_LONG).show();
                    abrirAreaPrincipal();
                }else{
                    Toast.makeText(LoginActivity.this,"Erro ao realizar Login" + e.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private  void alerta(String mensagem){
        Toast.makeText(LoginActivity.this,mensagem,Toast.LENGTH_SHORT).show();
    }
    public void eventoClick(){

    }

    //Excluir um usuario
    public void excluirUsuario() {
        FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
        user.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    //Log.d(TAG,"Conta deletada");
                }
            }
        });
    }
    public void verificarUsuarioLogado(){

        if(ParseUser.getCurrentUser()!=null){
            abrirAreaPrincipal();

        }
    }


}
