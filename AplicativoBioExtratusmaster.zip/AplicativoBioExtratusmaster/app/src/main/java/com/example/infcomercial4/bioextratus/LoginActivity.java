package com.example.infcomercial4.bioextratus;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputEditText;
import android.support.design.widget.TextInputLayout;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatTextView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import com.example.infcomercial4.bioextratus.bd.DataBase;
import com.example.infcomercial4.bioextratus.helpers.InputValidation;


public class LoginActivity extends AppCompatActivity {
    private final AppCompatActivity activity = LoginActivity.this;

    private NestedScrollView nestedScrollView;
    private Spinner spnGrupo;


    private TextInputLayout textInputLayoutEmail;
    private TextInputLayout textInputLayoutPassword;

    private TextInputEditText textInputEditTextEmail;
    private TextInputEditText textInputEditTextPassword;

    private AppCompatButton appCompatButtonLogin;

    private AppCompatTextView textViewLinkRegister;

    private InputValidation inputValidation;
    private DataBase dataBase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        buttonEntrar= (Button)findViewById(R.id.appCompatButtonRegister);
        buttonEntrar.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View v){

                Intent intent = new Intent(LoginActivity.this, MenuPrincipal.class);
                startActivity(intent);

            }

        });

        initViews();
        initListeners();
        initObjects();
    }

    /**
     * This method is to initialize views
     */
    private void initViews() {



        textInputLayoutEmail = (TextInputLayout) findViewById(R.id.textInputLayoutEmail);
        textInputLayoutPassword = (TextInputLayout) findViewById(R.id.textInputLayoutPassword);

        textInputEditTextEmail = (TextInputEditText) findViewById(R.id.textInputEditTextEmail);
        textInputEditTextPassword = (TextInputEditText) findViewById(R.id.textInputEditTextPassword);

        appCompatButtonLogin = (AppCompatButton) findViewById(R.id.appCompatButtonRegister);



    }

    /**
     * This method is to initialize listeners
     */
    private void initListeners() {
        appCompatButtonLogin.setOnClickListener((View.OnClickListener) this);

    }

    /**
     * This method is to initialize objects to be used
     */
    private void initObjects() {
        dataBase = new DataBase(activity);
        inputValidation = new InputValidation(activity);

    }

    /**
     * This implemented method is to listen the click on view
     *
     * @param v
     */

    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.appCompatButtonRegister:
                verifyFromSQLite();
                break;


        }
    }

    /**
     * This method is to validate the input text fields and verify login credentials from SQLite
     */
    private void verifyFromSQLite() {
        if (!inputValidation.isInputEditTextFilled(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextEmail(textInputEditTextEmail, textInputLayoutEmail, getString(R.string.error_message_email))) {
            return;
        }
        if (!inputValidation.isInputEditTextFilled(textInputEditTextPassword, textInputLayoutPassword, getString(R.string.error_message_email))) {
            return;
        }


    }

    /**
     * This method is to empty all input edit text
     */
    private void emptyInputEditText() {
        textInputEditTextEmail.setText(null);
        textInputEditTextPassword.setText(null);
    }
        public Button buttonEntrar;



    public void abrirAreaPrincipal(View view){
        Intent intent = new Intent(LoginActivity.this,MenuPrincipal.class);
        startActivity(intent);
    }


    public void abrirCadastroUsuario(View view){
        Intent intent = new Intent(LoginActivity.this,CadastrarUsuarioActivity.class);
        startActivity(intent);


    }
    public void abrirCadastroProduto(View view){
        Intent intent = new Intent(LoginActivity.this,CadastrarProdutoActivity.class);
        startActivity(intent);


    }




}
