package com.example.infcomercial4.bioextratus;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import com.example.infcomercial4.bioextratus.BDbioextratus.InventarioBD;
import com.example.infcomercial4.bioextratus.fragments.InventarioCreateFragment;
import com.example.infcomercial4.bioextratus.model.InventarioModel;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.util.ArrayList;

public class CadastrarInventario140 extends Activity {
    private EditText txtCodigo;
    private EditText txtDescricao;
    private EditText txtQuantidade;
    private EditText txtLote;
    private EditText txtArmazem;
    private Button btnCapture;
    private Button btnAdd;
    private Button btnCancel;
    private Button btnIncluir;
    private Object view;
    ListView lista;
    InventarioBD bd;
    ArrayList<InventarioModel> listView_Inventario;
    InventarioModel inventario;
    ArrayAdapter adapter;
    private InventarioCreateFragment createFragment = null;
    protected void onCreate (Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.inventario_activity);

        txtCodigo =(EditText)findViewById(R.id.txtCodigo);
        txtDescricao =(EditText)findViewById(R.id.txtDescricao);
        txtQuantidade =(EditText)findViewById(R.id.txtQuantidade);
        txtLote =(EditText)findViewById(R.id.txtLote);
        txtArmazem =(EditText)findViewById(R.id.txtArmazem);
        btnIncluir =(Button)findViewById(R.id.btnIncluir);
        btnCapture =(Button) findViewById(R.id.btnCapture);
        btnAdd =(Button)findViewById(R.id.btnAlterar);
        btnCancel=(Button)findViewById(R.id.btnCancel);

        btnIncluir.setOnClickListener(new android.view.View.OnClickListener(){
            public void onClick(View view){
                Intent intent = new Intent(CadastrarInventario140.this, FormularioInventario010.class);
                startActivity(intent);
            }

        });





    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo){
        MenuItem menuDelete = menu.add("Deletar este produto");
        menuDelete.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
            public boolean onMenuItemClick(MenuItem item){
                bd= new InventarioBD((CadastrarInventario140.this));
                bd.deletarProduto(inventario);
                bd.close();
                carregarProduto();
                return true;
            }

        });
    }
    protected void onResume(){
        super.onResume();
        //carregarProduto();
    }
    public void carregarProduto(){
        bd= new InventarioBD(CadastrarInventario140.this);
        //listView_Inventario= bd.get
        bd.close();

        if(listView_Inventario != null){
            adapter = new ArrayAdapter<InventarioModel>(CadastrarInventario140.this,android.R.layout.simple_list_item_1,listView_Inventario);
            lista.setAdapter(adapter);
        }
        finish();

    }

    public void barcodeCapture(View view) {
        IntentIntegrator intent = new IntentIntegrator(CadastrarInventario140.this);
        intent.initiateScan();
    }
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null){
            String barcode = result.getContents();
            if (barcode != null && !"".equals(barcode)){
                createFragment.setBarCode(barcode);

            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }






}


