package com.example.infcomercial4.bioextratus.adapters;

import android.content.Context;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.infcomercial4.bioextratus.R;
import com.example.infcomercial4.bioextratus.model.User;

import java.util.ArrayList;
import java.util.List;

public class UserAdapter extends ArrayAdapter<User> {

    private ArrayList<User> usuarios;
    public UserAdapter(@NonNull Context context, @NonNull ArrayList<User> usuarios){
        super(context,0,usuarios);
        this.usuarios = usuarios;
    }


    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        User usuario = usuarios.get(position);
        convertView = LayoutInflater.from(getContext()).inflate(R.layout.activity_login,null);

        TextView textViewEmail = (TextView)convertView.findViewById(R.id.editEmail);

        TextView textViewPassword = (TextView)convertView.findViewById(R.id.editSenha);

        textViewEmail.setText(usuario.getEmail().toString());
        textViewPassword.setText(usuario.getPassword().toString());
        return super.getView(position, convertView, parent);
    }
}
